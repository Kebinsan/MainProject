package com.project.smappy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmappyApplicationTests {

	@Test
	void contextLoads() {
	}

}
