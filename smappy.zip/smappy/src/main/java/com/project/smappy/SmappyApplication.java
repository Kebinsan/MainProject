package com.project.smappy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmappyApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmappyApplication.class, args);
	}

}
